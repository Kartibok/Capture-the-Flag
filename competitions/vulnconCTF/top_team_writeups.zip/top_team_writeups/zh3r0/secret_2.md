### writeup

https://cdn.discordapp.com/attachments/787747325169893416/790215472360587294/unknown.png

![](https://i.imgur.com/Z372sLF.png)
 try and error :/
