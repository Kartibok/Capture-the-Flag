## write up
Go on Date?

cipher = ddve uhkft fkpjet enfqdknis


key for cipher = ADCACACAADCACACAADCACACA


![](https://i.imgur.com/u7XCSMd.png)

flag = vulncon{date_shift_cipher_encodings}

