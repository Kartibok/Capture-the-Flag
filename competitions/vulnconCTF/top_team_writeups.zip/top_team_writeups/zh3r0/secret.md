### writeup

https://cdn.discordapp.com/attachments/787747325169893416/790215472360587294/unknown.png

https://github.com/carlospolop/privilege-escalation-awesome-scripts-suite/
this is the link
